<?php

define("HOSTNAME", "MySQL hostname");
define("USERNAME", "MySQL username");
define("PASSWORD", "MySQL password");
define("DATABASE", "MySQL Database");

?>
