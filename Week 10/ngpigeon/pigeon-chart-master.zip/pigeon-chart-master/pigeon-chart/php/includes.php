<?php

echo "
    <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
    <script src='pigeon-chart/js/angular.min.1.6.4.js'></script>
	<script src='pigeon-chart/js/underscore-min.js'></script>
	<script src='https://code.highcharts.com/highcharts.js'></script>
	<script src='https://code.highcharts.com/modules/series-label.js'></script>
	<script src='https://code.highcharts.com/modules/exporting.js'></script>
	<script src='pigeon-chart/js/grouped-categories.js'></script>
    <script src='pigeon-chart/js/pigeon-chart.js'></script>";

?>